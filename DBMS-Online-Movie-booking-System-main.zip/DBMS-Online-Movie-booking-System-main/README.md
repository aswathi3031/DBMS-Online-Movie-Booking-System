# Online_Movie_Ticket_Booking_Management_System
An online movie ticket booking management system is a web-based application that provides users with the ability to search for and purchase movie tickets from the convenience of their own homes. The system typically includes features such as a database of movies, theatres, and show timings, as well as an interface for users to search 
